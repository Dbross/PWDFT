#!/bin/bash

# Test script for robust CO on Pt(111) calculation
echo "=========================================="
echo "Testing Robust CO on Pt(111) Calculation"
echo "=========================================="

PWDFT_EXECUTABLE=${PWDFT_BIN:-../../../build/pwdft}

# Test 1: Robust SCF settings
echo "Test 1: Robust SCF settings..."
$PWDFT_EXECUTABLE < Pt111_CO_relax_robust.nw > Pt111_CO_relax_robust.out

# Check if robust version worked
if grep -q "job completed" Pt111_CO_relax_robust.out; then
    echo "✅ Robust SCF calculation completed successfully"
    
    # Check for NaN/Inf values
    nan_count=$(grep -c "NaN\|Inf" Pt111_CO_relax_robust.out || echo "0")
    if [ "$nan_count" -eq 0 ]; then
        echo "✅ No NaN/Inf values detected"
    else
        echo "⚠️ Found $nan_count NaN/Inf values (but calculation completed)"
    fi
    
    # Extract final energy
    final_energy=$(grep "Total DFT energy" Pt111_CO_relax_robust.out | tail -1 | awk '{print $NF}' || echo "N/A")
    echo "📊 Final energy: $final_energy"
    
else
    echo "❌ Robust SCF calculation failed"
    
    # Check what went wrong
    if grep -q "NaN\|Inf" Pt111_CO_relax_robust.out; then
        echo "❌ NaN/Inf values caused failure"
    fi
    
    if grep -q "Maximum iteration" Pt111_CO_relax_robust.out; then
        echo "❌ Maximum iterations reached"
    fi
fi

echo ""
echo "=========================================="
echo "Comparison with Original Input"
echo "=========================================="

# Test 2: Original input for comparison
echo "Test 2: Original input (for comparison)..."
$PWDFT_EXECUTABLE < Pt111_CO_relax.nw > Pt111_CO_relax.out

# Compare results
echo ""
echo "Comparison Summary:"
echo "-------------------"

if [ -f "Pt111_CO_relax_robust.out" ] && [ -f "Pt111_CO_relax.out" ]; then
    robust_nan=$(grep -c "NaN\|Inf" Pt111_CO_relax_robust.out || echo "0")
    original_nan=$(grep -c "NaN\|Inf" Pt111_CO_relax.out || echo "0")
    
    echo "NaN/Inf values:"
    echo "  Original: $original_nan"
    echo "  Robust:   $robust_nan"
    
    robust_completed=$(grep -c "job completed" Pt111_CO_relax_robust.out || echo "0")
    original_completed=$(grep -c "job completed" Pt111_CO_relax.out || echo "0")
    
    echo "Job completion:"
    echo "  Original: $original_completed"
    echo "  Robust:   $robust_completed"
    
    if [ "$robust_completed" -gt 0 ] && [ "$original_completed" -eq 0 ]; then
        echo "✅ Robust settings improved convergence!"
    elif [ "$robust_completed" -gt 0 ] && [ "$original_completed" -gt 0 ]; then
        echo "✅ Both versions completed successfully"
    else
        echo "❌ Both versions failed - may need additional tuning"
    fi
fi

echo ""
echo "=========================================="
echo "Recommendations"
echo "=========================================="

if [ "$robust_completed" -gt 0 ]; then
    echo "✅ Use robust SCF settings for Pt surface calculations"
    echo "✅ Key improvements:"
    echo "   - Random wavefunction initialization"
    echo "   - Relaxed tolerances"
    echo "   - Conservative mixing"
    echo "   - Kerker preconditioning"
else
    echo "⚠️ Additional tuning may be needed:"
    echo "   - Try even more relaxed tolerances"
    echo "   - Use different mixing schemes"
    echo "   - Adjust simulation cell size"
    echo "   - Check pseudopotential quality"
fi

echo ""
echo "Test completed!" 