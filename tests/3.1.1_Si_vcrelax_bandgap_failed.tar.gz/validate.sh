#!/bin/bash
if ! grep -q ">>> job completed at" si_vcrelax.out; then
  echo "FAIL: vc-relax calculation did not complete."
  exit 1
fi

# Extract final energy from the energies array in the JSON output
FINAL_ENERGY=$(grep "energies" si_vcrelax.out | tail -1 | sed 's/.*energies":\[[^,]*,[^,]*,[^,]*,[^,]*,\([^,]*\).*/\1/')
if [ -z "$FINAL_ENERGY" ] || [ "$FINAL_ENERGY" = "null" ]; then
  echo "FAIL: Could not extract energy from output."
  exit 1
fi

# For now, just check that the calculation completed and energy is reasonable
ENERGY_PER_ATOM=$(echo "$FINAL_ENERGY" | awk '{print $1 / 2.0}')
BENCHMARK_ENERGY="-2.8"
TOLERANCE="1.0"
IS_OK=$(echo "$ENERGY_PER_ATOM $BENCHMARK_ENERGY $TOLERANCE" | awk '{ diff = $1 - $2; if (diff < 0) diff = -diff; if (diff < $3) print "1"; else print "0"; }')

if [ "$IS_OK" = "1" ]; then
  echo "PASS: Energy per atom $ENERGY_PER_ATOM is within tolerance."
  exit 0
else
  echo "FAIL: Energy per atom $ENERGY_PER_ATOM is NOT within tolerance."
  exit 1
fi 